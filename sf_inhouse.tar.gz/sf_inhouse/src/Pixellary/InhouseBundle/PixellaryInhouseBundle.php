<?php

namespace Pixellary\InhouseBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PixellaryInhouseBundle extends Bundle
{
}
