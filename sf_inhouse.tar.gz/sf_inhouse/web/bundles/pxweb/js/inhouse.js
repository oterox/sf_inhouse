/**
 * @author oterox
 */
(function($) {

	
					
})(jQuery);
			
